# Proposal

## What will (likely) be the title of your project?

Acknowledging Our Waste

## In just a sentence or two, summarize your project. (E.g., "A website that lets you buy and sell stocks.")

A website that accesses data from local, state-wide or national disposals of food. Totalling daily
waste from just a few areas and then computing the dramatic effects of this waste on the Earth would
be displayed on the website

## In a paragraph or more, detail your project. What will your software do? What features will it have? How will it be executed?

My project will be a website that gathers data from Harvard dining halls along with other schools,
workplaces, and universities about food waste. The project will compute total waste values as well
as specific contributions at the level of the indivdual up to state-wide impacts. It will be using
data that is mainly entered manually into a table categorizing all values entered. It will give
statistics for each individual day and compare it with weekly data as well as years past data.

## If planning to combine CS50's final project with another course's final project, with which other course? And which aspect(s) of your proposed project would relate to CS50, and which aspect(s) would relate to the other course?

TODO, if applicable

## In the world of software, most everything takes longer to implement than you expect. And so it's not uncommon to accomplish less in a fixed amount of time than you hope.

### In a sentence (or list of features), define a GOOD outcome for your final project. I.e., what WILL you accomplish no matter what?

I will create a website that allows users to manually input their waste data. I will compile data
and make it accessible to the public and use this data to suggest ways to reduce waste.

### In a sentence (or list of features), define a BETTER outcome for your final project. I.e., what do you THINK you can accomplish before the final project's deadline?

In a better outcome I will be able to add features such as considering food that is being donated
and thus not being wasted. It will also compute predictions of what this kind of waste on a daily
basis will do to the Earth. Essentially it will use data inputed to present statistics related to
issues with waste contributing to climate change.

### In a sentence (or list of features), define a BEST outcome for your final project. I.e., what do you HOPE to accomplish before the final project's deadline?

in the best possible scenario, I would want to personalize the website for each individual
institution using the website. It would take data like the amount of food that was initially prepared
and the amount wasted to better determine how much food should be prepared in the first place.

## In a paragraph or more, outline your next steps. What new skills will you need to acquire? What topics will you need to research? If working with one of two classmates, who will do what?

I will start with a website and allow access and login so that each use has an individualized
experience. I will create forms to be filled out daily as well as constantly chanding data that
represents the amount of waste contributed by the users only. I will need to find ways to get data
that is not from users but is instead from other sources.
