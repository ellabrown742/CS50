# Status Report

#### Your name

Ella Brown

#### Your section leader's name

Heemyung Hwang

#### Project title

Minimizing Food Waste at Harvard

***

Short answers for the below questions suffice. If you want to alter your plan for your project (and obtain approval for the same), be sure to email your section leader directly!

#### What have you done for your project so far?

I have copied the starter code from the web tracks pset and have started to customize it to fit my project's goals.

#### What have you not done for your project yet?

I have not solved the problem of getting the API and using it to get data from the Harvard Dining halls website. I also need
to incorporate certain information into the database.

#### What problems, if any, have you encountered?

Using the API key from the dining hall's database.
