# Preproposal

## What idea(s) do you have for your final project?

I want to create a website, or possible mobile app(?) that everyone would ideally have open consistently
that tracks individual, local, national, and even global food waste. As one of the biggest contributors
to climate change. Having a way to input your own food waste while also examining the waste of others
will make people more aware of the damage they do daily.

Alternatively, instead of having this program be reliant on a user to input data, I could implement a
system that is in every trashcan, so that it weighs and determines the item being disposed of and display-
ing and/or communicating verbally what this particular item will negatively impact the Earth and instead
what could have been done with it (ie. repurposed, donated, stored for later use, not buying in the first
place).

I also could do something related to dining halls on campus, an extraordinary amount of food is wasted in
each dining hall for each meal. So i could create a program that would calculate demand for a particular
food so that overproduction doesn't occur. I could think of a way to account for food taken, but not eaten
by students.

## If you plan to collaborate with one or two classmates, what are their names, and who are their section leaders?

None

## Do you have any questions of your own?

Is this a sufficient project, does it have enough complexity?
