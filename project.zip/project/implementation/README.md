Starting/Loading the Webpage:

    After uploading all files into the IDE, execute "cd project" followed by "flask run" in the terminal window.
Then, click on the link that followes "Running on htt...". A new user will be brought to the login page by default.
If you have not created a profile yet, click register on the top right of the page. The page is meant for Harvard
Undergrads, so you will be asked to register with a username, password, and your upperclassmen house. If the registration
successful, you will redirected to the login page where you type in your username and password. If successful, you will
be redirected to index.html, otherwise an error page will pop up with an apology message. Register and login are both case-
sensitive.

    From the homepage, you are able to access the ordering page and the totals page. On the homepage, you are able to see
your own orders as well as university-wide daily orders (anyone that has used the webpage and has ordered something will
be included in the database and this table). The user can go to the order page, follow the directions on the top of the
page (enter location and meal id, not the words breakfast, lunch, and dinner) and then be redirected to menu.html where you
can select food items and your desired quantity. Click done to be redirected to the homepage. From here you can click Totals
where you are sent to total.html and you can see all food that has been ordered through this webpage, all in order based on the
food item